# Capacity, Robustness, Attack Surface & Non-goals

**Date:** 2026-08-31  
**Sources:** `references/sigil-deep-research-report.md` § Capacity/ECC/Threats + `references/chatgpt/2026-08-31.md` § Robustness ladder + measured attack matrices in `sigil/README.md` and Q-series findings.  
**See also:** `research/media-credential/technology/cryptographic-security.md` (§2 entropy fallacy, §3 five attacks, §5 "Complexity is attack surface", §6 carrier economics) — normative security model for this file's threat matrix; `findings/2026-08-31-cryptographic-security-analysis.md` — executive summary.

## 1. Carrier ceilings (math, not promise)

From current constants (`dct.rs`: 8×8 blocks, `512` sync blocks; `dwt_embed.rs`: `W/2×H/2` LH band, `512` sync positions; repetition `8`):

- `N_DCT = floor(W/8)*floor(H/8)`, `B_DCT,max ≈ floor((N_DCT-512)/8)`
- `B_DWT,addr ≈ floor((floor(W/2)*floor(H/2)-512)/8)` — address space only; filling it is not validated for distortion/steganalysis.
- `TrustMark Q`: `100b → BCH_5 → 61 data bits` (fixed).

| Resolution | DCT blocks | DCT logical ceiling | DWT logical addr ceiling | Learned |
| ---------: | ---------: | ------------------: | -----------------------: | ------: |
|    256×256 |      1,024 |          64 b / 8 B |          1,984 b / 248 B |    61 b |
|    512×512 |      4,096 |        448 b / 56 B |        8,128 b / 1,016 B |    61 b |
|  1024×1024 |     16,384 |     1,984 b / 248 B |       32,704 b / 4,088 B |    61 b |
|  1254×1254 |     24,336 |     2,978 b / 372 B |       49,077 b / 6,134 B |    61 b |

Credential's `128b` opaque token already motivates `≥512×` preferred, `1024×` comfortable — especially once `framing + MAC + ECC + interleave` are counted. TrustMark's `61b` is only a `locator`, not a high-value standalone bearer secret.

## 2. What to actually promise — `carrier / robust / stealth`

Steganography theory (Cachin, square-root law): payload vs cover size vs detectability are coupled; "how many coefficients can I write" is not a product capacity.

Distinguish:

- `carrier_capacity` — addressable bits (table above).
- `robust_capacity` — bits at target Frame Error Rate under a declared attack profile.
- `stealth_capacity` — bits at a detector threshold.

Only `robust_capacity` and `stealth_capacity` belong in user docs.

### Measured FER — 128b credential ladder (CTX-0025, 5 trials at 512/1024, 1 at 1254)

**Method:** `capglyph ladder` binary (`src/bin/ladder.rs`) reuses `capglyph_core::framing` (CBOR+HMAC) + `ecc` (BCH/Repetition + soft LLR) + `registration` (Translation NCC). Payload `16 B` → sealed `54 B` → ECC → differential `±64` (DCT) / `±256/32` (DWT). Synthetic covers `make_image` + `make_geometry` (64-pt line), `KeyMaterial::from_keys([0x11;32],[0x22;32])`, `Placement::Skeleton` (DCT) / LH (DWT), `attack.family`/`severity` populated (fixes v2 identity-only bug). `results.json` with `attack.family`/`severity` at `ladder-output/results.json` (531 records, 512/1024 quick 5 trials, 1254 1 trial, plus 512 full 1 trial for blur/scale/crop/rotate). Archive `ladder-ctx0025-20260831.tar.gz` (sha256 `92e65b5292ea34f7...599a706a`).

**Carrier vs robust capacity (128b, best profile per size):**
- `512 DCT` → `Repetition8` **not viable** (insufficient blocks, FER 1.0) → `Bch{t=2}` is the viable fallback (FER 0.20 at PNG, 0.40 at JPEG q75/q50) — matches §1 `56 B` logical ceiling after framing.
- `512 DWT` → `Repetition8` or `Bch` both **FER 0.0** at PNG and JPEG q30/50/75 (LH 65k coeffs ample).
- `1024 DCT` → `Repetition8` **FER 0.0** at PNG and all JPEG (soft LLR majority) — the robust choice; `Bch` shows 0.20–0.40 at PNG/JPEG.
- `1024 DWT` and `1254` both **FER 0.0** at PNG and JPEG for all profiles.

| Attack family | Severity | 512 DCT (Bch{t=2}) | 512 DWT | 1024 DCT (Rep8) | 1024 DWT | 1254 DCT (Rep8) | 1254 DWT | Note |
|---------------|----------|-------------------|---------|-----------------|----------|-----------------|----------|------|
| identity | — | **0.20** (1/5) | **0.00** (0/5) | **0.00** (0/5) | **0.00** (0/5) | **0.00** (0/1) | **0.00** (0/1) | PNG, no attack |
| jpeg | q75 | **0.40** (2/5) | **0.00** (0/5) | **0.00** (0/5) | **0.00** (0/5) | **0.00** (0/1) | **0.00** (0/1) | |
| jpeg | q50 | **0.40** (2/5) | **0.00** (0/5) | **0.00** (0/5) | **0.00** (0/5) | **0.00** (0/1) | **0.00** (0/1) | |
| jpeg | q30 | **1.00** (5/5) | **0.00** (0/5) | **0.00** (0/5) | **0.00** (0/5) | **0.00** (0/1) | **0.00** (0/1) | DCT Bch fails at q30, Rep8/DWT survive |
| blur | σ1.0 | **1.00** (1/1) | **0.00** (0/1) | 1.00 (1/1)† | 0.00† | 0.00† | 0.00† | DWT LH robust to mild blur |
| blur | σ2.0 | **1.00** (1/1) | **1.00** (1/1) | 1.00† | 1.00† | 1.00† | 1.00† | needs learned |
| resize | 0.7× | **1.00** (1/1) | **0.00** (0/1) | 1.00† | 0.00† | 0.00† | 0.00† | DWT survives 0.7×, DCT needs registration |
| resize | 0.5× | **1.00** (1/1) | **1.00** (1/1) | 1.00† | 1.00† | 1.00† | 1.00† | needs learned/scale-robust |
| crop | 0.90/0.75/0.50 | **1.00** (1/1) | **1.00** (1/1) | 1.00† | 1.00† | 1.00† | 1.00† | blind FER 1, registered with Translation NCC recovers 0.7×/crop 0.90 with residual (see §4) |
| rotate | 5°/15° | **1.00** (1/1) | **1.00** (1/1) | 1.00† | 1.00† | 1.00† | 1.00† | blind 1, registered recovers with NCC (5° error <0.01) |
| learned | — | — | — | — | — | — | — | TrustMark Q 61b available as locator, not 128b bearer |

† Extrapolated from 512 full 1-trial + 1024 quick 5-trial JPEG trend; 1024/1254 full blur/scale/crop not yet run with 5 trials — treat as provisional and re-measure before claiming.

**Stealth (PSNR):** `512 DCT` 33.1 dB, `512 DWT` 44.2 dB, `1024 DCT` 38.5 dB, `1024 DWT` 45.1 dB (marked vs original, synthetic). DWT is more invisible due to LH band and flat-aware `±32` (see `dwt_embed.rs` `FLAT_ID_EMBED_STRENGTH`).

**Implication:** `512 → DWT` (any profile, FER 0 at JPEG q30) is the safe 128b carrier; `512 DCT` is viable only with `Bch{t=2}` at FER 0.2–0.4 (not 0) and fails at q30. `1024 → DCT Repetition8` or `DWT` both FER 0 at all JPEG; `1254` is ideal (FER 0 even at q30 for Rep8). For blur/scale, DWT survives mild cases, DCT does not without registration; crop/rotate require `registered-residual` (`R = I_aligned - I_original` via `TranslationRegistration`) — blind FER 1, registered FER 0 for 0.7×/crop 0.90 in pilot (see ladder `registered_ok`).

The DWT flat-region nuance (`±256` textured, `±32` flat — `FLAT_ID_EMBED_STRENGTH` in `dwt_embed.rs`) already shows why "ceilings" mislead: filling the entire LH band at full strength would wreck flat regions.

## 3. Channel coding upgrade path

Cox spread-spectrum insight (energy in perceptually significant components) maps directly to Sigil's `±strength + repetition` today (`dct.rs ID ±64` + `dwt ±256/32`).

Needed stack — CTX-0020 implements the MVP column; `Next` remains future:

| Layer      | MVP (CTX-0020) — `sigil/src/{framing,ecc,interleave} + carrier`                                                                                                                                                 | Next                                           |
| ---------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------- |
| Framing    | CBOR array `[v, type, flags, len, payload]` + `HMAC-SHA256` (`KeyMaterial::k_mac`, `framing::seal/open`)                                                                                                        | capability negotiation, `kid` rotation         |
| Detection  | `HMAC` fail-closed (not CRC) — `open` rejects tag mismatch                                                                                                                                                      | CRC ≠ MAC (CRC kept only for compat shim)      |
| Short ECC  | `BCH` (`ecc::Profile::Bch{t}`) — Hamming(7,4) t=1, BCH(15,7) t=2, BCH(31,16) t=3 with brute-force syndrome decode                                                                                               | profiled `BCH(63,36)` t=5, Chase soft          |
| Burst      | byte interleave (`interleave.rs`, QR-style `depth`) + `RS` systematic `GF(256)` (`ecc::Profile::RsInterleaved{n,k,depth}`) — encode via `rs::encode_systematic`, decode hard-check (correction deferred for RS) | adaptive erasure, Berlekamp-Massey full        |
| Long       | deferred                                                                                                                                                                                                        | LDPC/Polar + soft-decision                     |
| Modulation | `±differential` at `ID_TARGET (3,4)` / `LH` — `A+delta, B-delta` per bit, `Δ=64` (DCT) / `256/32` (DWT flat-aware)                                                                                              | host-adaptive / QIM experiments                |
| Decode     | hard majority → `SoftBit{hard, llr}` with `llr=2*diff/sigma`, `sigma via MAD`, `ecc::decode` LB-combining for Repetition, `decode_hard` for BCH                                                                 | `magnitude → confidence/LLR` + soft in (Chase) |
| Spatial    | interleaving across regions via keyed PRNG (`prf_k_embed` + `prng_block_list` / `prng_band_positions` excluding `SEED_MAGIC` sync)                                                                              | multi-scale interleave                         |

Interleaving matters more than deeper repetition for crop.

### CTX-0020 measured FER — 128b opaque token (16 B payload → CBOR+HMAC → sealed 54 B → ECC)

_Payload → CBOR framing (compact array, `serde_bytes` byte-string, overhead 6 B + `HMAC 32 B` = 38 B) → sealed `54 B` for 16 B credential → ECC → differential ±Δ → soft LLR. Carrier `DCT` (`F[3,4]` differential, `Δ64`) and `DWT LH` (`Δ256/32`). Bench: 20 trials per cell, 1024×1024 and 512×512, `KeyMaterial::from_keys([0x11;32],[0x22;32])`, `PayloadType::Credential`, `Placement::Skeleton` (DCT) / geometry LH (DWT)._

**DCT / DWT, 128b, `BCH{t=3}` (31,16) and `Repetition8` — PNG / JPEG q75 / q50:**

| Size | Carrier | Profile     | PNG FER         | JPEG q75 FER    | JPEG q50 FER    | Notes                                                                                                                                |
| ---- | ------- | ----------- | --------------- | --------------- | --------------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| 512  | DCT     | Repetition8 | 1.00 (20/20)    | 1.00 (20/20)    | 1.00 (20/20)    | **insufficient blocks** — Repetition needs `54*64=3456 bits → 6912 blocks + sync 512 > 4096` → fail-closed `insufficient DCT blocks` |
| 512  | DCT     | BCH{t=3}    | **0.00** (0/20) | **0.05** (1/20) | **0.10** (2/20) | `31,16` rate 0.52 → `837 bits → 1674 blocks + sync 512 = 2186 < 4096` — fits, `1.15%` BER clean (9/837), `1.67%` at q75 (14/837)     |
| 512  | DWT     | Repetition8 | 0.00 (0/20)     | 0.00 (0/20)     | 0.00 (0/20)     | LH band 256×256 = 65k coeff → ample                                                                                                  |
| 512  | DWT     | BCH{t=3}    | 0.00 (0/20)     | 0.00 (0/20)     | 0.00 (0/20)     |                                                                                                                                      |
| 1024 | DCT     | Repetition8 | 0.00 (0/20)     | 0.00 (0/20)     | 0.00 (0/20)     | `6912 blocks < 16384` → fits                                                                                                         |
| 1024 | DCT     | BCH{t=3}    | 0.00 (0/20)     | 0.00 (0/20)     | 0.00 (0/20)     |                                                                                                                                      |
| 1024 | DWT     | Repetition8 | 0.00 (0/20)     | 0.00 (0/20)     | 0.00 (0/20)     |                                                                                                                                      |
| 1024 | DWT     | BCH{t=3}    | 0.00 (0/20)     | 0.00 (0/20)     | 0.00 (0/20)     |                                                                                                                                      |

_RS `RsInterleaved{15,10,4}` is encode-only in CTX-0020 (systematic `GF(256)` parity via `rs::encode_systematic`, decode is hard-check `parity mismatch` → FER 1.00 at any error, reported as `1.67%` BER but `1.00` FER). Full Berlekamp-Massey/Chien/Forney deferred to CTX-0025 ladder._

**Implication for product:** 128b credential is **safe at 512 with `DCT BCH{t=3}`** (FER 0.05 at q75, 0.10 at q50) and **ideal at 1024** (FER 0 for all). `Repetition8` at 512 DCT is **not viable** (capacity), but `Repetition8` at 1024 DCT or any DWT at 512 is **FER 0** and is the JPEG-robust choice (`Repetition` soft LLR majority survives q50 where `BCH t=3` shows 0.10). Recommend: `512 → DWT Repetition or DCT BCH{t=3}`, `1024 → DCT Repetition` (simplest, most robust soft path). 256×256 cannot carry 128b with framing+ECC (needs ≥512).

**Carrier vs robust capacity (updated):** For `128b` the `carrier_capacity` table (§1) says `512 DCT = 56 B` logical ceiling; after `framing 38 B` the remaining `18 B` is the true budget, so only `BCH` (rate ~0.5) fits, `Repetition (×8)` does not. This is the correct `robust_capacity` view.

> Bench source: `sigil/tests/framed.rs` (clean) + `sigil/src/bin/fer_bench.rs` (removed before merge, output preserved above). Run via `cargo test --test framed` and `cargo run --bin fer_bench --release` in `sigil/.worktrees/ctx-0020` on `1024x1024` synthetic `make_image_seeded` (seeded PRNG, 20 trials). Reproducible in CI with `cargo test --test framed` (4 tests). WASM: `cargo check --target wasm32-unknown-unknown --lib` passes (ciborium + serde_bytes are wasm-safe, no clap/glob in graph beyond existing leak).

## 4. Placement & detector correctness

- Correctness fixes already landed on `feat/wasm-in-memory-api`: `dct` edge `insufficient_geometry` fail-closed (`edge_blocks_with_budget`), `dwt` differential pairing (`±8` pairs), blind `median/MAD` DWT statistic (`verify_v2`, O(N log N), no cover artifact), deterministic edge tie-breaking. Keep these as the new baseline — do not regress to "silently pick a random eligible set" or "write all +delta" behaviors.
- Remaining wiring bug: `dwt_embed::embed` `_placement` is dead code — placement ladder cannot honestly claim DWT coverage until wired and tested.

## 5. Threat matrix (what actually threatens credential vs message)

> For why these five rows are the correct decomposition (and why `2^{25M}` carrier space, `4096-bit` keys, and algorithm stacking do not help), see `research/media-credential/technology/cryptographic-security.md` §§2–6. That doc defines the normative `Guess / Forge / Extract / Detect / Steal` model, the `128–256-bit` entropy rule, **"Complexity is attack surface"**, and versioned `Sigil-Embed-v1→v2` (TLS-like) deprecation.

Security properties to claim:

`Authenticity` (no forged credential), `Authorization` (scope-bound), `Replay Control` (quota/time), `Revocation` (online), `Carrier Integrity` (large edits → fail-closed).

Not to claim by default: `Uncopyability`, `Non-transferability`, `Screenshot-proof`, `AI-regeneration-proof`, `Undetectable by all machines` — bearer semantics mean copy is allowed; damage is bounded.

| Threat                               | Credential              | Message              | Severity         | Defense                                                                            |
| ------------------------------------ | ----------------------- | -------------------- | ---------------- | ---------------------------------------------------------------------------------- |
| File copy / replay                   | replayable              | readable/forwardable | High             | quota/expiry/WebAuthn binding                                                      |
| Double-spend / concurrent consume    | repeat consume          | —                    | Critical         | atomic DB `UPDATE ... RETURNING` + tx                                              |
| Brute-force token / learned 61b enum | forged bearer           | locator guess        | High/Med-High    | ≥128b opaque ID; 61b only as locator; rate limit                                   |
| Known-cover / multi-copy collusion   | residual exposure       | carrier analysis     | High             | cover not root; MAC/sig; limit reuse; per-family variants; fingerprinting (Tardos) |
| Removal / forgery                    | DoS / illegal access    | lost / injected      | Med/Critical     | fail-closed; HMAC/sig + DB existence                                               |
| JPEG/resize/crop/rotate              | decode fail / sync loss | same                 | Med/High         | ECC/interleave/mode-select; registration/pilot                                     |
| Screenshot / diffusion regen         | fail today (non-goal)   | destroyed            | High if needed   | recapture-trained model (StegaStamp-style 56b) or declare non-goal                 |
| Steganalysis                         | credential discovered   | covert exposed       | High for message | payload minimization, adaptive placement, benchmark                                |
| Verify oracle                        | helps removal tuning    | helps detection      | Med              | binary response, rate limit, no confidence leak                                    |
| Cover repo / signing key leak        | mass forgery            | forged pointer       | Critical         | encrypted storage, KMS/HSM, rotation, `kid`                                        |
| IDOR on object                       | —                       | others' ciphertext   | High             | capability authorization                                                           |

Cover reuse note: `C + Δ1, C + Δ2, ...` with many recipients leaks the common `C` under collusion (median/average). Policy: low-value coupons may share a cover family; medium-value limits fan-out; high-value uses `per-credential cover variant` / deterministic diversification.

Generative regeneration / screenshot: for credential, `img2img(pass.png)` destroys the token → `invalid` (DoS, not a forgery). For message, it is a reliability failure. Need different SLAs.

## 6. WASM & evidence boundary

- Browser today: `embed_bytes / verify_bytes / extract_bytes` on `alpha/dct/dwt` only (file-system-free, `wasm32-unknown-unknown` CI gate); `learned` excluded (ONNX Runtime); `verify_bytes` is presence-only (no secret-key path).
- MVP split: browser does `decode/validate + public extraction + preflight`; server does `private original + original-assisted verify + KMS + DB + consume/revoke`. **Never** ship issuer HMAC / signing private key / private originals to WASM.
- Evidence chain for disputes: preserve `original_cover.sha256 + issued_image.sha256 + submitted_image.sha256 + credential_record + embed_profile + extraction_metrics + sigil_version + signer_certificate + timestamp + signed_audit_log`. Chinese electronic-data rules and e-signature law (`可靠电子签名` = exclusive control + tamper-evidence) mean an HMAC alone is not a legal signature — pair with `Ed25519 / C2PA + trusted timestamp + custody chain` if court value is wanted. C2PA `valid/trusted manifest` proves provenance binding + integrity, not factual truth of claims.

## 7. Non-goals to keep explicit

- Screenshot/print-scan robustness, AI-regeneration robustness, anti-AI-training cloaking, and `known-cover-proof` are **non-goals for v1**. Declaring them would contradict the measured matrix and the published `roadmap`/readmes. This section's carrier-economics rationale (spend bits on `ECC / distributed / PRF-placed / multi-channel` rather than larger keys) is normatively stated in `research/media-credential/technology/cryptographic-security.md` §6.
- Any `benchmark` command / matrix visualization is future work — the current `dct`+`edge`/`prng` arms are now comparable on budgets, but DWT arms are not yet.

## 8. Cryptographic security companion

The entropy fallacy (`carrier 2^{25M}` vs `secret 10^8`), `MD5 hash-function vs Sigil system`, `Guess/Forge/Extract/Detect/Steal` decomposition, and the principle **"Complexity is attack surface"** (single-primitive agility vs stacking, `Sigil-Embed-v1→v2` like TLS) are now documented in `research/media-credential/technology/cryptographic-security.md` and summarized in `findings/2026-08-31-cryptographic-security-analysis.md`. Treat `research/media-credential/technology/capacity-robustness-and-threats.md` §§2/5 and that companion as one normative unit.
